import { CloudFrontRequestHandler } from 'aws-lambda';

declare const handler: CloudFrontRequestHandler;

export { handler };
