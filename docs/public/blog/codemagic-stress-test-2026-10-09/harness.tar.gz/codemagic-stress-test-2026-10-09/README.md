# Reproduce the October 9, 2026 metadata-delivery comparison

This archive contains the fixture generator, Worker wrapper, and load generator
used for the published measurement of Hot Updater v1.0 (`1.0.0-rc.43`, commit
in `versions.json`) against a static manifest in Codemagic Patch's format.
Account and resource IDs in the Wrangler config are placeholders. The load
generator (`load.mjs`) keeps the stages, scheduling, warmups, timeout, and
statistics of the September 10, 2026 harness.

Release Catalog responses carry:

```
Cache-Control: public, max-age=0, s-maxage=5
CDN-Cache-Control: public, max-age=5, stale-while-revalidate=5, stale-if-error=0
```

Workers Cache reads `CDN-Cache-Control` and, when a Catalog expires, serves it
from cache (`CF-Cache-Status: UPDATING`) while the Worker revalidates in the
background.

## Scope

The Hot Updater side runs its real D1-backed Catalog and `apiKeys()` path. The
Codemagic side serializes a synthetic manifest with the upstream serializer and
serves it through Cloudflare Static Assets with Patch's own manifest cache
policy. It does not run the full Patch stack, R2, an SDK, artifact resolution,
or an actual bundle download.

`worker.ts` adds diagnostic headers to every origin response
(`x-benchmark-origin-ms`, `x-benchmark-d1-queries`, `x-benchmark-d1-spans`).
Cached copies repeat them, so they are not used for any latency number.
`worker.ts` also reads `BENCH_STRIP_CDN_CACHE_CONTROL`: unset (the published
run), responses are the server's; set to `1`, it deletes `CDN-Cache-Control`
for the same-deployment control described below.

## Prepare

Use a Hot Updater checkout at the commit in `versions.json` and a Codemagic
Patch checkout at 3d4ad8b7a7d4ebedbe7cd0513742c1418625221c. Install Hot Updater
dependencies from its checked-in lockfile. The runtime was Node v24.15.0,
pnpm 11.6.0, Wrangler 4.99.0.

Extract this directory under the Hot Updater checkout's `.codex/benchmarks/`.
The scripts' relative imports expect that location. From the checkout root:

```sh
pnpm --filter @hot-updater/protocol run build
pnpm --filter @hot-updater/plugin-core run build
pnpm --filter @hot-updater/plugin-api-keys --filter @hot-updater/plugin-insights --filter @hot-updater/plugin-remote-config run build
pnpm --filter @hot-updater/server run build
node .codex/benchmarks/codemagic-stress-test-2026-10-09/prepare.mjs /absolute/path/to/codemagic-patch
```

(`pnpm build` at the root builds the same packages.) The generator writes a
fresh client key to a mode-0600 credentials.json file, a full schema plus
fixtures to seed.sql, static assets, and fixtures.json. Do not publish
credentials.json or point this schema import at an existing application's
database.

## Deploy to resources you own

Run Wrangler from the Cloudflare package (`cd plugins/cloudflare && pnpm exec
wrangler ...`). Verify the selected account with `whoami`. Choose a unique
Worker and database name; update the placeholder names in wrangler.jsonc.
Create a new D1 database with `d1 create <name> --location apac --no-update-config`
and replace the placeholder database_id. Pass the explicit `--config` path
for every resource/deployment command.

Then use, in order:

1. `d1 execute <database-name> --remote --file <path-to-seed.sql> --yes`
2. `types <path-to-worker-configuration.d.ts>`
3. `deploy --dry-run`
4. `deploy`

The config enables Workers Cache and serves matching Static Assets before the
Worker. The database was created with an APAC hint, and D1 reported
`served_by_colo: SIN`. Actual D1
placement and client-to-edge routing may differ on a rerun.

Before loading, verify HTTP 200 plus the expected metadata for both fixture
paths, CF-Cache-Status HIT after warmup, and HTTP 401 on the Catalog path
without a client key. The Catalog response should carry
`Cache-Control: public, max-age=0, s-maxage=5`,
`CDN-Cache-Control: public, max-age=5, stale-while-revalidate=5, stale-if-error=0`,
`Vary: Accept-Encoding, x-api-key`, and an `ETag`; the load generator sends no
`If-None-Match`. Requests in the first seconds after a deploy can answer 404
while the deployment propagates; verify after it settles. Keep credentials
local.

## Run and inspect

Set BENCH_ALLOWED_ORIGIN to the exact origin of your own new test deployment:

```sh
BENCH_ALLOWED_ORIGIN=https://your-isolated-worker.your-subdomain.workers.dev \
  node .codex/benchmarks/codemagic-stress-test-2026-10-09/load.mjs \
  https://your-isolated-worker.your-subdomain.workers.dev
```

It sends 81,000 measured requests plus 120 warmups over 12 HTTP/2 sessions.
The 250/500 requests-per-second stages each last six seconds; each of the three
1,000 requests-per-second stages lasts twelve seconds per target. Targets run
sequentially with alternating order. The stream timeout is ten seconds of
inactivity, not an absolute wall-clock deadline. results.json contains each
sample's latency, scheduler lag, HTTP status, payload validity, POP and cache
status. Published p95 and p99 use nearest rank over the 36,000 samples per
target at 1,000 requests/s. The p50 comparison takes the median of the three
per-run p50s. "HIT" counts only `CF-Cache-Status: HIT`; `UPDATING` responses
are cache-served too but are counted separately.

The load generator's diagnostic lower-bound aggregate fields are removed from
the published summary and results. Request-level `queries`/`rowsRead` are
cached response-header observations and must not be summed as total database
work.

## Same-deployment control

Network conditions and D1 placement differ between runs, so the run was
followed by a control on the same Worker and D1: redeploy with
`--var BENCH_STRIP_CDN_CACHE_CONTROL:1`, confirm that responses carry no
`CDN-Cache-Control` and that `CF-Cache-Status: REVALIDATED` appears again
after expiry, then run `load.mjs` unchanged. The published run is the one
with the header; the control's samples are published separately
(`results-control.json.gz`) and summarized under `control` in summary.json.

## Clean up

After collecting results, delete only the Worker and database created for this
rerun using `wrangler delete <worker-name>` and `wrangler d1 delete <database-name>`.
Remove the generated local credentials.json. The test's Worker, D1 and
credential file were removed after the run.
