import { AsyncLocalStorage } from 'node:async_hooks';
import { env } from 'cloudflare:workers';
import { Hono } from '../../../plugins/cloudflare/node_modules/hono';
import { createHotUpdater } from '../../../packages/server/dist/index.mjs';
import { apiKeys } from '../../../packages/server/dist/plugins/api-keys/index.mjs';
import { d1Database } from '../../../plugins/cloudflare/src/worker/d1Database';

// Per-request diagnostic counters only. The production reader/auth/cache is unchanged.
const metrics = new AsyncLocalStorage<{ queries: number; rowsRead: number; startedAt: number; spans: string[] }>();
const database = d1Database({
  prepare(sql: string) {
    const prepared = env.DB.prepare(sql);
    const table = /\bFROM\s+"?([\w]+)/i.exec(sql)?.[1] ?? '?';
    return {
      bind(...params: readonly unknown[]) {
        const bound = prepared.bind(...params);
        return {
          async all() {
            const current = metrics.getStore();
            if (current) current.queries++;
            const startedAt = Date.now();
            const result = await bound.all();
            if (current) {
              current.rowsRead += result.meta.rows_read;
              // Table, start offset and duration of each D1 read, in ms from the request's start.
              current.spans.push(`${table}@${startedAt - current.startedAt}+${Date.now() - startedAt}`);
            }
            return result;
          },
        };
      },
    };
  },
  async batch() { throw new Error('The benchmark is read-only'); },
});
const hotUpdater = createHotUpdater({ database, plugins: [apiKeys()] });
const app = new Hono();
app.mount('/', request => hotUpdater.handlers.client(request));

export default {
  async fetch(request: Request) {
    const current = { queries: 0, rowsRead: 0, startedAt: Date.now(), spans: [] as string[] };
    return metrics.run(current, async () => {
      const response = await app.fetch(request);
      const result = new Response(response.body, response);
      result.headers.set('x-benchmark-origin', crypto.randomUUID());
      result.headers.set('x-benchmark-d1-queries', String(current.queries));
      result.headers.set('x-benchmark-d1-rows-read', String(current.rowsRead));
      // Diagnostics for the origin run that produced this response; cached copies repeat them.
      result.headers.set('x-benchmark-origin-ms', String(Date.now() - current.startedAt));
      result.headers.set('x-benchmark-d1-spans', current.spans.join(' '));
      // Same-deployment control only: answers as the server did before CDN-Cache-Control.
      if ((env as { BENCH_STRIP_CDN_CACHE_CONTROL?: string }).BENCH_STRIP_CDN_CACHE_CONTROL === '1') result.headers.delete('cdn-cache-control');
      return result;
    });
  },
} satisfies ExportedHandler<Env>;
