import http2 from 'node:http2';
import { performance } from 'node:perf_hooks';
import { readFile, writeFile } from 'node:fs/promises';
import { once } from 'node:events';
import { setTimeout as sleep } from 'node:timers/promises';

const dir = import.meta.dirname;
const origin = process.argv[2];
if (!origin || origin !== process.env.BENCH_ALLOWED_ORIGIN) {
  throw new Error('Set BENCH_ALLOWED_ORIGIN to your own isolated benchmark deployment');
}
const fixtures = JSON.parse(await readFile(`${dir}/fixtures.json`));
const { apiKey } = JSON.parse(await readFile(`${dir}/credentials.json`));
const sessions = await Promise.all(Array.from({ length: 12 }, async () => {
  const session = http2.connect(origin);
  session.on('error', error => console.error('HTTP2 session:', error.code));
  await once(session, 'connect');
  return session;
}));
let nextSession = 0;
const inc = (map, key) => { map[key] = (map[key] ?? 0) + 1; };
function request(target, scheduledAt, pathOverride, headersOverride = {}) {
  const startedAt = performance.now();
  const path = pathOverride ?? (target === 'hot' ? fixtures.hotPath : fixtures.patchPath);
  return new Promise(resolve => {
    let headers = {}, body = '', completed = false;
    let stream;
    const finish = error => {
      if (completed) return;
      completed = true;
      const endedAt = performance.now();
      let valid = false;
      if (!error && headers[':status'] === 200) {
        try {
          const json = JSON.parse(body);
          valid = target === 'hot'
            ? json.releases?.[0]?.bundleId === fixtures.expectedBundleId
            : json.target_package_hash === fixtures.expectedPatchHash;
        } catch {}
      }
      resolve({
        status: headers[':status'] ?? error?.code ?? 'error', valid,
        latency: endedAt - startedAt, scheduledLatency: endedAt - scheduledAt,
        scheduleLag: startedAt - scheduledAt,
        cache: headers['cf-cache-status'] ?? 'absent',
        pop: String(headers['cf-ray'] ?? '').split('-').at(-1),
        originId: headers['x-benchmark-origin'] ?? null,
        queries: Number(headers['x-benchmark-d1-queries'] ?? 0),
        rowsRead: Number(headers['x-benchmark-d1-rows-read'] ?? 0),
        bytes: Buffer.byteLength(body), headers, error: error?.message,
      });
    };
    try {
      stream = sessions[nextSession++ % sessions.length].request({
        ':method': 'GET', ':path': path,
        'accept-encoding': 'identity',
        ...(target === 'hot' ? { 'x-api-key': apiKey } : {}),
        ...headersOverride,
      });
      stream.setEncoding('utf8');
      stream.setTimeout(10000, () => {
        finish({ code: 'TIMEOUT', message: '10 second timeout' });
        stream.close(http2.constants.NGHTTP2_CANCEL);
      });
      stream.on('response', value => { headers = value; });
      stream.on('data', value => { body += value; });
      stream.on('end', () => finish());
      stream.on('error', error => finish(error));
      stream.end();
    } catch (error) { finish(error); }
  });
}
function percentile(values, quantile) {
  const sorted = [...values].sort((a,b) => a-b);
  return Number(sorted[Math.min(sorted.length - 1, Math.ceil(quantile * sorted.length) - 1)].toFixed(3));
}
async function run(target, rate, seconds, repetition) {
  // Warm all transport connections and each endpoint; these requests are excluded.
  for (let i = 0; i < sessions.length; i++) {
    const warm = await request(target, performance.now());
    if (!warm.valid) throw new Error(`Invalid warmup ${target}: ${warm.status} ${warm.error ?? ''}`);
  }
  const count = rate * seconds;
  const start = performance.now();
  const pending = [];
  let sent = 0;
  while (sent < count) {
    const due = Math.min(count, Math.floor((performance.now() - start) * rate / 1000) + 1);
    while (sent < due) {
      pending.push(request(target, start + sent * 1000 / rate));
      sent++;
    }
    if (sent < count) await sleep(2);
  }
  const offeredEnd = performance.now();
  const rows = await Promise.all(pending);
  const elapsed = performance.now() - start;
  const status = {}, cache = {}, pops = {}, originWork = new Map();
  for (const row of rows) {
    inc(status, row.status); inc(cache, row.cache); inc(pops, row.pop);
    // Cached headers repeat. Count each origin response exactly once.
    if (row.originId) originWork.set(row.originId, { queries: row.queries, rowsRead: row.rowsRead });
  }
  const result = {
    target, offeredRps: rate, seconds, repetition, requests: rows.length,
    correctResponses: rows.filter(row => row.valid).length,
    statuses: status, cache, pops,
    sendDurationMs: Number((offeredEnd-start).toFixed(3)),
    drainMs: Number(Math.max(0,elapsed-seconds*1000).toFixed(3)),
    completedRpsIncludingDrain: Number((rows.filter(row => row.valid).length/(elapsed/1000)).toFixed(2)),
    p50Ms: percentile(rows.map(x=>x.latency),.5),
    p95Ms: percentile(rows.map(x=>x.latency),.95),
    p99Ms: percentile(rows.map(x=>x.latency),.99),
    maxMs: percentile(rows.map(x=>x.latency),1),
    scheduledP95Ms: percentile(rows.map(x=>x.scheduledLatency),.95),
    scheduleLagP99Ms: percentile(rows.map(x=>x.scheduleLag),.99),
    distinctOriginResponsesObserved: originWork.size,
    // A CDN 304 revalidation may retain cached diagnostic headers. These are
    // lower bounds from observed response identities, NOT total D1 billing.
    observedUniqueResponseQueriesLowerBound: [...originWork.values()].reduce((sum,x)=>sum+x.queries,0),
    observedUniqueResponseRowsReadLowerBound: [...originWork.values()].reduce((sum,x)=>sum+x.rowsRead,0),
    responseBytes: [...new Set(rows.filter(x=>x.valid).map(x=>x.bytes))],
  };
  console.log(JSON.stringify(result));
  return { result, samples: rows.map(({ headers, ...row }) => row) };
}
const report = { startedAt: new Date().toISOString(), origin, node: process.version, fixtures, runs: [] };
try {
  for (const [rate, seconds, repetition, order] of [
    [250, 6, 0, ['hot','patch']], [500, 6, 0, ['patch','hot']],
    [1000, 12, 1, ['hot','patch']], [1000, 12, 2, ['patch','hot']],
    [1000, 12, 3, ['hot','patch']],
  ]) {
    for (const target of order) {
      report.runs.push(await run(target,rate,seconds,repetition));
      await writeFile(`${dir}/results.json`, JSON.stringify(report));
    }
  }
} finally {
  for (const session of sessions) session.close();
  report.finishedAt = new Date().toISOString();
  await writeFile(`${dir}/results.json`, JSON.stringify(report));
}
