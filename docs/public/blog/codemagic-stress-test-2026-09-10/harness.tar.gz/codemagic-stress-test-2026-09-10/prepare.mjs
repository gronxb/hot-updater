import { randomBytes, createHash } from 'node:crypto';
import { mkdir, writeFile, readFile } from 'node:fs/promises';
import { resolve, dirname } from 'node:path';
import { fileURLToPath, pathToFileURL } from 'node:url';
import { encodeChannelKey, createReleaseCatalogScopeKey } from '../../../packages/core/dist/index.mjs';
import { compileReleaseCatalog } from '../../../plugins/plugin-core/dist/index.mjs';

const dir = dirname(fileURLToPath(import.meta.url));
const root = resolve(dir, '../../..');
const codemagic = process.argv[2];
if (!codemagic) throw new Error('Pass the pinned Codemagic checkout path');
const { manifestSerializer } = await import(pathToFileURL(resolve(codemagic, 'server/src/worker/manifestSerializer.ts')).href);
const key = randomBytes(32).toString('base64url');
const channelKey = encodeChannelKey('production');
const scopeKey = createReleaseCatalogScopeKey({ channelKey, platform: 'ios', strategy: 'APP_VERSION' });
const release = {
  bundleId: '00000000-0000-7001-8000-000000000001',
  channelId: 'bench-production', createdAtMs: 1, enabled: true,
  fingerprintHash: null, id: '00000000-0000-7000-8000-000000000001',
  kind: 'BUNDLE', message: 'Benchmark release', operation: 'DEPLOY',
  platform: 'ios', revision: 1, rolloutCohortCount: 1000,
  shouldForceUpdate: false, sourceReleaseId: null, strategy: 'APP_VERSION',
  targetAppVersion: '*', targetCohorts: [], updatedAtMs: 1,
};
const compiled = await compileReleaseCatalog({ releases: [release], strategy: 'APP_VERSION' });
const q = value => value === null ? 'NULL' : typeof value === 'number' ? String(value) : `'${String(value).replaceAll("'", "''")}'`;
const insert = (table, row) => `INSERT INTO ${table} (${Object.keys(row).join(',')}) VALUES (${Object.values(row).map(q).join(',')});\n`;
let sql = await readFile(resolve(root, 'plugins/cloudflare/worker/migrations/0001_hot-updater_1.0.0.sql'), 'utf8');
sql += '\n' + insert('channels', { id: release.channelId, name: 'production' });
sql += insert('release_catalogs', {
  scope_key: scopeKey, catalog_id: 'benchmark-20260910', strategy: 'APP_VERSION',
  channel_id: release.channelId, channel_key: channelKey, platform: 'ios',
  fingerprint_hash: null, generation: 1, payload: compiled.canonicalPayload,
  catalog_hash: compiled.catalogHash, byte_size: compiled.byteSize,
  is_tombstone: 0, updated_at_ms: 1,
});
sql += insert('api_keys', {
  id: 'benchmark-client', hash: createHash('sha256').update(key).digest('base64url'),
  name: 'Isolated benchmark', prefix: key.slice(0, 6), role: 'client',
  created_at_ms: 1, revoked_at_ms: null,
});
const manifest = manifestSerializer.serialize({
  isMandatory: false, releaseLabel: 'v1', releaseNotes: 'Benchmark release',
  rolloutPercentage: 100, targetPackageHash: 'a'.repeat(64),
  fullBundleSize: 1048576,
  fullBundleUrl: 'https://example.invalid/benchmark/bundle.tar.zst',
});
await mkdir(resolve(dir, 'assets/patch/production/1.0.0'), { recursive: true });
await writeFile(resolve(dir, 'assets/patch/production/1.0.0/manifest.json'), manifest.json);
await writeFile(resolve(dir, 'assets/_headers'), '/patch/*\n  Cache-Control: public, max-age=0, s-maxage=300, must-revalidate\n  X-Benchmark-Delivery: static-assets\n');
await writeFile(resolve(dir, 'seed.sql'), sql);
await writeFile(resolve(dir, 'credentials.json'), JSON.stringify({ apiKey: key }), { mode: 0o600 });
await writeFile(resolve(dir, 'fixtures.json'), JSON.stringify({
  hotPath: `/release-catalogs/app-version/ios/${channelKey}/1.0.0`,
  patchPath: '/patch/production/1.0.0/manifest.json',
  expectedBundleId: release.bundleId,
  expectedPatchHash: 'a'.repeat(64),
  patchBytes: Buffer.byteLength(manifest.json), compiledBytes: compiled.byteSize,
  scopeKey,
}, null, 2));
console.log(JSON.stringify({ prepared: dir, patchBytes: Buffer.byteLength(manifest.json), compiledBytes: compiled.byteSize }));
