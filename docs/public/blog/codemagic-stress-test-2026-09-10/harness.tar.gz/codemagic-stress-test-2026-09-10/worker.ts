import { AsyncLocalStorage } from 'node:async_hooks';
import { env } from 'cloudflare:workers';
import { Hono } from '../../../plugins/cloudflare/node_modules/hono';
import { createHotUpdater } from '../../../packages/server/dist/index.mjs';
import { d1Database } from '../../../plugins/cloudflare/src/worker/d1Database';

// Per-request diagnostic counters only. The production reader/auth/cache is unchanged.
const metrics = new AsyncLocalStorage<{ queries: number; rowsRead: number }>();
const database = d1Database({
  prepare(sql: string) {
    const prepared = env.DB.prepare(sql);
    return {
      bind(...params: readonly unknown[]) {
        const bound = prepared.bind(...params);
        return {
          async all() {
            const current = metrics.getStore();
            if (current) current.queries++;
            const result = await bound.all();
            if (current) current.rowsRead += result.meta.rows_read;
            return result;
          },
        };
      },
    };
  },
  async batch() { throw new Error('The benchmark is read-only'); },
});
const hotUpdater = createHotUpdater({ database, clientAccess: { type: 'api-key' } });
const app = new Hono();
app.mount('/', request => hotUpdater.handlers.client(request));

export default {
  async fetch(request: Request) {
    const current = { queries: 0, rowsRead: 0 };
    return metrics.run(current, async () => {
      const response = await app.fetch(request);
      const result = new Response(response.body, response);
      result.headers.set('x-benchmark-origin', crypto.randomUUID());
      result.headers.set('x-benchmark-d1-queries', String(current.queries));
      result.headers.set('x-benchmark-d1-rows-read', String(current.rowsRead));
      return result;
    });
  },
} satisfies ExportedHandler<Env>;
