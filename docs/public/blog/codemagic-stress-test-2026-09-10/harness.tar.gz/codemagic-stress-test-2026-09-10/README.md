# Reproduce the September 10, 2026 metadata-delivery comparison

This archive contains the fixture generator, Worker wrapper, and load generator
used for the published measurement. The load generator now requires an explicit
BENCH_ALLOWED_ORIGIN instead of the removed deployment's hostname. Account and
resource IDs in the Wrangler config are placeholders. Timing and scheduling
logic is unchanged; diagnostic D1 totals are labeled as lower bounds because
CDN revalidation can retain earlier response headers.

## Scope

The Hot Updater side runs its real D1-backed Catalog/authentication path. The
Codemagic side serializes a synthetic manifest with the upstream serializer and
serves it through Cloudflare Static Assets. It does not run the full Patch stack,
R2, an SDK, artifact resolution, or an actual bundle download. Use the article's
fixture and cache conditions when interpreting any rerun.

## Prepare

Use a separate Hot Updater checkout at
0dbbefb4c536053fb6369d51722d3c72b43a26a7 and a Codemagic Patch checkout at
f22294f7c2599b79979b8620e5cb6db4bf3bdf0a. Install dependencies from the checked-in
lockfiles. The original runtime was Node v24.15.0, pnpm 11.6.0, Wrangler 4.99.0.

Extract this directory under the Hot Updater checkout's `.codex/benchmarks/`.
The scripts' relative imports expect that location. From the checkout root:

```sh
pnpm --filter @hot-updater/core --filter @hot-updater/plugin-core --filter @hot-updater/server run build
pnpm exec tsx .codex/benchmarks/codemagic-stress-test-2026-09-10/prepare.mjs /absolute/path/to/codemagic-patch
```

The TS loader is needed to import Codemagic's TypeScript serializer. Ensure tsx
is available locally. The generator writes a fresh client key to a mode-0600
credentials.json file, a full schema plus fixtures to seed.sql, static assets,
and fixtures.json. Do not publish credentials.json or point this schema import
at an existing application's database.

## Deploy to resources you own

Use the Cloudflare package's installed Wrangler (`pnpm --dir plugins/cloudflare
exec wrangler`). Verify the selected account with `whoami`. Choose a unique
Worker and database name; update the placeholder names in wrangler.jsonc.
Create a new D1 database with `d1 create <name> --location apac --no-update-config`
and replace the placeholder database_id. Pass the explicit `--config` path
for every resource/deployment command.

Then use, in order:

1. `d1 execute <database-name> --remote --file <path-to-seed.sql> --yes`
2. `types <path-to-worker-configuration.d.ts>`
3. `deploy --dry-run`
4. `deploy`

The config enables Workers Cache and serves matching Static Assets before the
Worker. It uses compatibility date 2026-09-10; the pinned Hot Updater template
used 2026-08-13. The original resource was provisioned with an APAC hint, but
actual D1 placement and client-to-edge routing may differ on a rerun.

Before loading, verify HTTP 200 plus the expected metadata for both fixture
paths, CF-Cache-Status HIT after warmup, and HTTP 401 on the Catalog path without
a client key. Keep credentials local. The credentials.json file is read by the
load generator, not uploaded as an asset.

## Run and inspect

Set BENCH_ALLOWED_ORIGIN to the exact origin of your own new test deployment:

```sh
BENCH_ALLOWED_ORIGIN=https://your-isolated-worker.your-subdomain.workers.dev \
  node .codex/benchmarks/codemagic-stress-test-2026-09-10/load.mjs \
  https://your-isolated-worker.your-subdomain.workers.dev
```

It sends 81,000 measured requests plus 120 warmups over 12 HTTP/2 sessions.
The 250/500 requests-per-second stages each last six seconds; each of the three
1,000 requests-per-second stages lasts twelve seconds per target. Targets run
sequentially with alternating order. The stream timeout is ten seconds of
inactivity, not an absolute wall-clock deadline. results.json contains each
sample's latency, scheduler lag, HTTP status, payload validity, POP and cache
status. Published p95 uses nearest rank over the 36,000 samples per target at
1,000 requests/s. The p50 comparison takes the median of the three per-run p50s.

The archived load generator's extra diagnostic lower-bound aggregate fields
may be absent from the published summary. They are not used for any claim in
the article. Request-level `queries`/`rowsRead` are cached response-header
observations and must not be summed as total database work.

## Clean up

After collecting results, delete only the Worker and database created for this
rerun using `wrangler delete <worker-name>` and `wrangler d1 delete <database-name>`.
Remove the generated local credentials.json. The original test's Worker, D1
and credential file were removed after the run.
