# v0 vs v1 update check, same account and same data — October 9, 2026

A controlled rerun of the September 8, 2026 update-check measurement. Both
deployments were created fresh for this run in the same Cloudflare account,
from each version's own managed Cloudflare Worker template, with D1 databases
created the same way, and seeded with the same 16 bundles through each
version's own write path. The runner is the September 8 runner with only the
endpoint versions, app version and v1 payload check changed.

## Results

Measured from **2026-10-09T07:44:44.683Z to 07:46:24.892Z UTC**. Each
deployment received 1,000 measured checks at 10 requests/second after 10
warmups. All 2,000 measured responses passed status and payload validation;
the run did not abort.

| Metric | v0 | v1 |
| --- | ---: | ---: |
| Measured checks | 1,000 | 1,000 |
| HTTP or payload failures | 0 | 0 |
| Mean | 295.1 ms | 58.6 ms |
| p50 | 301.3 ms | 50.0 ms |
| p95 | 371.4 ms | 118.9 ms |
| p99 | 415.2 ms | 135.5 ms |
| Min / max | 199.4 / 494.6 ms | 45.0 / 152.9 ms |
| CF-Cache-Status | absent ×1,000 (no Workers Cache) | HIT 961, UPDATING 39, REVALIDATED 0, MISS 0 |
| Decoded body | 4 bytes (`null`) | 6,284 bytes (Catalog, 11 releases + 16 rollback releases) |
| Edge POP (CF-Ray suffix) | KIX 486, NRT 287, HKG 227 | HKG 1,000 |
| D1 location reported | APAC, served_by_colo SIN, primary | APAC, served_by_colo SIN, primary |

From the unrounded values: p95 −68.0%, p50 −83.4%, mean −80.2%.
`(1 - v1 / v0) * 100`.

Same-POP subset (HKG only, from requests.csv): v0 n=227, p50 221.3 ms,
p95 297.8 ms, mean 233.8 ms; v1 n=1,000, p50 50.0 ms, p95 118.9 ms. By cache
status, v1 HIT (n=961) p50 50.0 / p95 119.0 ms and UPDATING (n=39) p50 50.5 /
p95 118.9 ms: an expired Catalog was served from cache while it revalidated,
so no measured request waited on the Worker. The single REVALIDATED response
was the first warmup request.

## Dataset (identical logical data in both)

- App version `1.0.0`, iOS, channel `production`, fingerprint none.
- 16 bundles (uuidv7 IDs with fixed timestamps, `harness/fixtures.mjs`), all
  enabled, rollout 1000/1000 cohorts, no target cohorts, no force update.
  The same 16 IDs in both deployments.
- The installation has the newest bundle (`01a0a783-6000-75cc-a022-4a90588b9563`)
  and checks again. v0 answers `null`. v1 answers the Catalog whose first
  release is that bundle; `selectDesiredRelease` from `@hot-updater/protocol`
  picks the installed release, so nothing is downloaded. (Checked before the
  run: an older installed bundle selects the newest one.)
- v0 rows were written by 0.36.18's Cloudflare `d1Database` with
  `appendBundle` + `commitBundle`, the calls `hot-updater deploy` 0.x makes.
- v1 rows were written by `assembleServer` (cli-tools) over the managed
  provider's `d1Database` and `plugins` (insights, apiKeys, remoteConfig),
  through `core.deploy` once per bundle, as `hot-updater deploy` does. Core
  compiled the Release Catalog (generation 16, 3,870 stored bytes). The served
  Catalog lists 11 of the 16 releases in `releases` (the compiler keeps up to
  11 distinct bundles per cohort, enough to skip 10 crashed bundles) and all
  16 in `rollbackReleases`. The one
  client API key was created through the apiKeys plugin API, as
  `hot-updater api-key create` does. No catalog row was hand-written.

## Deployments

| | v0 | v1 |
| --- | --- | --- |
| Server-reported version | `0.36.18` (`/api/check-update/version`) | `1.0.0-rc.42` (`/version`) |
| Code | origin/main `fd46758cb` | `fix/catalog-cache-revalidation` `8f0c81b2f` (1.0.0-rc.42 `4f62e3c47` + Catalog `CDN-Cache-Control`) |
| Worker | `plugins/cloudflare/worker` prebuilt `dist/index.js` | same |
| compatibility_date | 2025-01-24 | 2026-08-13 |
| Workers Cache | not configured | `cache.enabled: true` |
| Schema | migrations 0001–0005 via `d1 migrations apply --remote` | migration 0001 (1.0.0) via `d1 migrations apply --remote` |
| Client access | no key | one apiKeys() client key |
| Path | `/api/check-update/app-version/ios/1.0.0/production/<nil uuid>/<installed id>/<cohort 1..1000>` | `/release-catalogs/app-version/ios/cHJvZHVjdGlvbg/1.0.0` |

v1 response headers (verified before the run): `Cache-Control: public,
max-age=0, s-maxage=5`, `CDN-Cache-Control: public, max-age=5,
stale-while-revalidate=5, stale-if-error=0`, `Vary: Accept-Encoding,
x-api-key`, `ETag: "sha256:…"`, `Content-Type:
application/vnd.hot-updater.release-catalog+json; version=1`. HTTP 401
without the key; MISS then HIT on the first probes. v0 response headers:
`Content-Type: application/json` only, no Cache-Control or Vary.

The Worker configs were prepared exactly as each version's `init` does
(`deployWorker` / `prepareWorkerDeployment`: D1 binding, v0 `JWT_SECRET` var,
v1 `BUCKET_NAME` var and `STORAGE_DOWNLOAD_URL_SIGNING_KEY` secret, v0's
`%%BUCKET_NAME%%` migration transform), with one exception below. See
`harness/config/` (placeholders).

## Differences from September 8, 2026

- Same account, fresh deployments, same 16-bundle dataset and same installed
  bundle ID in both; September 8 used two existing deployments with different
  data (v0: 66 bundles / 16 for the app version; v1: 3 releases).
- Versions: 0.36.18 vs 0.35.2, and 1.0.0-rc.42 + the Catalog
  `CDN-Cache-Control` change vs 1.0.0-rc.3. With that change, expired Catalogs
  are served as `UPDATING` instead of waiting as `REVALIDATED`.
- App version `1.0.0` in both (was 1.4.0 / 1.5.0).
- v1 payload check: the first release is the installed bundle with full
  rollout and no target cohorts, instead of `releases.length === 1` (the
  shared fixture has 16 releases). The v1 body is 6,284 bytes, not 785.
- **No R2 bucket was bound** in either Worker (both templates declare one).
  Neither measured path reads storage: v0 returns `null` before resolving a
  download URL, and the v1 Catalog route reads only D1. Consequence: a v0
  check from an older bundle would fail on these deployments (it needs
  `env.BUCKET` to sign the download URL); it was not part of the workload.
- D1 for both was created with `--location apac` (0.x/1.x `init` passes no
  hint); both reported APAC / SIN. September 8 reported ICN.
- The runner also writes `requests.csv` (POP suffix only, no URLs or full Ray
  IDs). Scheduling, concurrency cap, timeout, timing and nearest-rank
  statistics are byte-identical to the September 8 runner.
- Edge routing differed between the two Workers from the same client: every
  v1 request landed in HKG; v0 was spread over KIX, NRT and HKG. The HKG-only
  subset above is the closest like-for-like timing comparison.

## Environment

One Node.js v24.15.0 process (pnpm 11.6.0, Wrangler 4.99.0) on an Apple M4 Mac
(macOS 27.0.1), both streams concurrently, HTTP connection
reuse, alternating dispatch order. No Insights events, release mutations,
artifact requests or downloads were generated by the measured workload.

## Files

- `summary.json` — runner output (same shape as September 8).
- `requests.csv` — every request, warmups labeled; POP suffix only.
- `versions.json` — commits, versions, compatibility dates, SHA-256 of the
  measured-path source files and of each deployed `dist/index.js`.
- `harness/` — `fixtures.mjs`, `seed-v0.mjs`, `seed-v1.mjs`, `run.mjs`,
  `config/wrangler.v{0,1}.json` (placeholders).

## Reproduce

1. Check out both commits; `pnpm install`, then build
   `pnpm --filter "@hot-updater/cloudflare..." build` in each.
2. For each version: copy `plugins/cloudflare/worker` to a staging folder,
   replace `wrangler.json` with `harness/config/wrangler.vN.json` (fill in a new
   D1 id/name; v0: a random `JWT_SECRET`; v0 migrations: replace
   `%%BUCKET_NAME%%`), `wrangler d1 create <name> --location apac`,
   `wrangler d1 migrations apply <name> --remote`, `wrangler deploy --name
   <worker>`; v1: `wrangler secret put STORAGE_DOWNLOAD_URL_SIGNING_KEY`.
3. Seed with `CLOUDFLARE_ACCOUNT_ID`, `CLOUDFLARE_API_TOKEN` (D1 write),
   `V0_DB`/`V1_DB` set: `node harness/seed-v0.mjs <v0 checkout>` and
   `node harness/seed-v1.mjs <v1 checkout> <private key file>`.
4. Write a private env file with `HOT_UPDATER_API_KEY`, `BENCH_V0_BASE_URL`,
   `BENCH_V1_BASE_URL`, `BENCH_V0_CURRENT_BUNDLE_ID`,
   `BENCH_V1_CURRENT_BUNDLE_ID` (both the newest fixture ID), then
   `node --env-file=<file> harness/run.mjs <out dir>`.
5. Delete the Workers and D1 databases afterwards.

## Cleanup

Both temporary Workers and both D1 databases were deleted after the run.
The Workers API answered "This Worker does not exist" (10007), `d1 info`
could not find either database, `d1 list` showed none, and both workers.dev
hosts answered 404 (cache-busted). No R2 bucket was created. Credential files
were deleted.
