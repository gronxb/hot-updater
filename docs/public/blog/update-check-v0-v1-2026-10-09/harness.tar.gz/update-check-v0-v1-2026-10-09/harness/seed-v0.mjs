// Seeds the v0 deployment's D1 the way `hot-updater deploy` 0.x writes a
// bundle: the Cloudflare provider's d1Database (Cloudflare REST API), then
// appendBundle + commitBundle per bundle.
// Usage: node seed-v0.mjs <v0 checkout> (env: CLOUDFLARE_ACCOUNT_ID, V0_DB, CLOUDFLARE_API_TOKEN)
import { resolve } from 'node:path';
import { pathToFileURL } from 'node:url';
import { APP_VERSION, BUCKET, CHANNEL, PLATFORM, bundles } from './fixtures.mjs';

const root = process.argv[2];
const { d1Database } = await import(pathToFileURL(resolve(root, 'plugins/cloudflare/dist/index.mjs')).href);
const factory = d1Database({
  accountId: process.env.CLOUDFLARE_ACCOUNT_ID,
  databaseId: process.env.V0_DB,
  cloudflareApiToken: process.env.CLOUDFLARE_API_TOKEN,
});
const databasePlugin = typeof factory === 'function' ? await factory() : factory;
for (const b of bundles) {
  await databasePlugin.appendBundle({
    shouldForceUpdate: false,
    platform: PLATFORM,
    fileHash: b.fileHash,
    gitCommitHash: b.gitCommitHash,
    message: b.message,
    id: b.id,
    enabled: true,
    channel: CHANNEL,
    targetAppVersion: APP_VERSION,
    fingerprintHash: null,
    storageUri: `r2://${BUCKET}/${b.id}/bundle.zip`,
    metadata: { app_version: APP_VERSION },
    assetBaseStorageUri: `r2://${BUCKET}/${b.id}/files`,
    manifestFileHash: b.manifestFileHash,
    manifestStorageUri: `r2://${BUCKET}/${b.id}/manifest.json`,
    rolloutCohortCount: 1000,
  });
  await databasePlugin.commitBundle();
}
console.log(JSON.stringify({ appended: bundles.length }));
