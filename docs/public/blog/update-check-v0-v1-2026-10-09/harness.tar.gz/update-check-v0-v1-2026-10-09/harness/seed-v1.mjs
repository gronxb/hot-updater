// Seeds the v1 deployment's D1 the way `hot-updater deploy` and
// `hot-updater api-key create` 1.x write: assembleServer over the managed
// Cloudflare provider's d1Database (Cloudflare REST API) and its plugins
// (insights, apiKeys, remoteConfig), then core.deploy (bundle + release +
// compiled Release Catalog in one transaction) and the apiKeys plugin API.
// Usage: node seed-v1.mjs <v1 checkout> <private key file>
//   (env: CLOUDFLARE_ACCOUNT_ID, V1_DB, CLOUDFLARE_API_TOKEN)
import { writeFileSync } from 'node:fs';
import { resolve } from 'node:path';
import { pathToFileURL } from 'node:url';
import { APP_VERSION, BUCKET, CHANNEL, PLATFORM, bundles } from './fixtures.mjs';

const [root, keyFile] = process.argv.slice(2);
const load = path => import(pathToFileURL(resolve(root, path)).href);
const { assembleServer } = await load('packages/cli-tools/dist/index.mjs');
const { d1Database, plugins } = await load('plugins/cloudflare/dist/index.mjs');
const server = assembleServer({
  database: d1Database({
    accountId: process.env.CLOUDFLARE_ACCOUNT_ID,
    databaseId: process.env.V1_DB,
    cloudflareApiToken: process.env.CLOUDFLARE_API_TOKEN,
  }),
  plugins,
});
await server.core.ready();
// One bundle per deploy, as `hot-updater deploy` runs once per release.
for (const b of bundles) {
  await server.core.deploy([{
    bundle: {
      id: b.id,
      platform: PLATFORM,
      gitCommitHash: b.gitCommitHash,
      metadata: { app_version: APP_VERSION },
      assetBaseStorageUri: `r2://${BUCKET}/${b.id}/files`,
      manifestFileHash: b.manifestFileHash,
      manifestStorageUri: `r2://${BUCKET}/${b.id}/manifest.json`,
    },
    release: {
      channel: CHANNEL,
      enabled: true,
      fingerprintHash: null,
      message: b.message,
      rolloutCohortCount: 1000,
      shouldForceUpdate: false,
      targetAppVersion: APP_VERSION,
    },
  }]);
}
const created = await server.api.apiKeys.create({ name: 'Update-check benchmark' });
writeFileSync(keyFile, `HOT_UPDATER_API_KEY=${created.apiKey}\n`, { mode: 0o600 });
console.log(JSON.stringify({ deployed: bundles.length, apiKeyCreated: Boolean(created.apiKey) }));
await server.database?.dispose?.();
