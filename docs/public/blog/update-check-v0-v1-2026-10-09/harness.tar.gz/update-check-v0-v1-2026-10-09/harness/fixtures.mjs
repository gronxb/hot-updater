// The one logical dataset both deployments receive: 16 iOS bundles on the
// production channel targeting app version 1.0.0, all enabled, full rollout,
// no cohort restriction. IDs are uuidv7 with fixed, increasing timestamps,
// so the newest bundle is the last one in both versions' ordering.
import { createHash } from 'node:crypto';

const hex = (seed, length) => createHash('sha256').update(seed).digest('hex').slice(0, length);

const uuidv7 = (ms, seed) => {
  const t = ms.toString(16).padStart(12, '0');
  const r = hex(seed, 20);
  const variant = ((parseInt(r[3], 16) & 0x3) | 0x8).toString(16);
  return `${t.slice(0, 8)}-${t.slice(8, 12)}-7${r.slice(0, 3)}-${variant}${r.slice(4, 7)}-${r.slice(7, 19)}`;
};

export const APP_VERSION = '1.0.0';
export const CHANNEL = 'production';
export const PLATFORM = 'ios';
export const BUCKET = 'hu-uc-bench-unused';
const start = Date.UTC(2026, 8, 1, 0, 0, 0);

export const bundles = Array.from({ length: 16 }, (_, i) => {
  const id = uuidv7(start + i * 86_400_000, `hot-updater-update-check-bench-${i}`);
  return {
    id,
    message: `Benchmark bundle ${i + 1}`,
    gitCommitHash: hex(`commit-${i}`, 40),
    fileHash: hex(`bundle-${i}`, 64),
    manifestFileHash: hex(`manifest-${i}`, 64),
  };
});

export const installedBundleId = bundles.at(-1).id;
